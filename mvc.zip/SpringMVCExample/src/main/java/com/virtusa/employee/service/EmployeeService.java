package com.virtusa.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.employee.DAO.LoginDAO;
import com.virtusa.employee.model.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	private LoginDAO loginDAO;
	
	public EmployeeService() {
		System.out.println("EmployeeService");
	}
	
		
	public void loginService(Employee employee) {
		System.out.println("LoginService");
		loginDAO.loginData(employee);
	}
}
