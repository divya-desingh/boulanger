package com.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.HibernateConnection.Hibernate_Connection;
import com.main.Admin;
import com.main.Items;
import com.main.Table1;
import com.main.Users;



public class DAO {
	
	Hibernate_Connection h = new Hibernate_Connection();
	Session session = h.getConnection();

	
	public void addTable(Table1 t) {
		
		Transaction tx=session.beginTransaction();
		
		
		session.save(t);
		tx.commit();
		
		session.close();
	
		System.out.println("Saved");
		
	}
	
	
	public Items addItem(Items i) {
	   
	    Transaction t = session.beginTransaction();
	    
	    session.save(i); 
	    
	    
	    String s = "Pavan123";
	    List<Items> result = session.createQuery("from Items where itemId=:itemid").setParameter("itemid",s).list();
		 
	    Items i1 = null;
	    for(Items item : result) {
	    	i1 = new Items(item.getItemName(),item.getItemId(),item.getItemDescription(),item.getItemCost(),item.getItemImageUrl());
	    }  
	    
	    
	    
	    t.commit();  
	    
	
	    session.close();
	    
		System.out.println("Saved");
		return i1;
	
   }
	
	public Items getItemsData() {
		
		
		List<Items> result = session.createQuery("from Items").list();
		 
	    Items i1 = null;
	    for(Items item : result) {
	    	i1 = new Items(item.getItemName(),item.getItemId(),item.getItemDescription(),item.getItemCost(),item.getItemImageUrl());
	    }  
		
		return i1;
	}
	
	public void addUser(Users u) {
		
		Transaction tx=session.beginTransaction();
		
			
		session.save(u);
		tx.commit();
		
		session.close();
	
		System.out.println("Saved");
		
	}
	
	public Users loginData(String email) {
		
		
		System.out.println("Came");
		Transaction tx=session.beginTransaction();
		
			
		
		List<Users> result = session.createQuery("from Users where email=:email").setParameter("email",email).list();
		 
	    Users u1 = null;
	    for(Users user : result) {
	    	u1 = new Users(user.getUserName(),user.getEmail(),user.getPassword(),user.getMobileNumber(),user.getAddress());
	        System.out.println(user.getEmail());
	        System.out.println(user.getPassword());
	    }  
        
	    tx.commit();
        session.close();
        return u1;
	    
	}
	
	
	public Admin adminloginData(String email) {
Transaction tx=session.beginTransaction();
		
			
		
		List<Admin> result = session.createQuery("from Admin where email=:email").setParameter("email",email).list();
		 
	    Admin a1 = null;
	    for(Admin admin : result) {
	    	a1 = new Admin(admin.getUserName(),admin.getEmail(),admin.getPassword(),admin.getMobileNumber(),admin.getAddress());
	        System.out.println(admin.getEmail());
	        System.out.println(admin.getPassword());
	    }  
        
	    tx.commit();
        session.close();
        return a1;
	}
	
	
	
	public int updateUserData(String email,String value,String option) {
		
	    Transaction tx=session.beginTransaction();  
	    Query q;
	    
	    switch(option) {
	    case "name":
	    	q=session.createQuery("update Users set userName=:a where email=:e"); 
	    	break;
	    case "email":
	    	q=session.createQuery("update Users set email=:a where email=:e"); 
	    	break;
	    case "address":
	    	q=session.createQuery("update Users set address=:a where email=:e");
	    	break;
	    case "mobileNumber":
	    	
	    	q=session.createQuery("update Users set mobileNumber=:a where email=:e");
	    	break;
	    default:
	    	 q=session.createQuery("update Users set simply=:a where email=:e"); 
	    	 break;
	    }
	    
	    long l = 0;
	    if(option.equals("mobileNumber")) {
	    	l = Long.parseLong(value);
	    	q.setParameter("a",l);
	    }
	    else {
	    q.setParameter("a",value);
	    }
	    q.setParameter("e",email);  
	      
	    int status=q.executeUpdate();  
	    System.out.println(status);  
	    tx.commit();
	     
	    session.close();   
		return status;
		
	}
	
	public List<Table1> tableData() {
		
Transaction tx=session.beginTransaction();
		
			
		
		List<Table1> result = session.createQuery("from Table1").list();
		 
//	    Table1 t1 = null;
//	    for(Table1 table1 : result) {
//	    	t1 = new Table1(table1.getFirstName(),table1.getLastName(),table1.getEmail(),table1.getNumberOfPeople(),table1.getPhone(),table1.getDate1(),table1.getTime(),table1.getMsg());
//	    }  
//        
	    tx.commit();
        session.close();
        return result;
		
	}
	
	
	
}
