package com.dto;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.main.Table1;


@WebServlet("/ReserveTableServlet")
public class ReserveTableServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Table1 t = new Table1();
		t.setFirstName(request.getParameter("mfname"));
		t.setLastName(request.getParameter("mlname"));
		t.setEmail(request.getParameter("memail"));
		t.setNumberOfPeople(request.getParameter("mpeople"));
		t.setPhone(request.getParameter("mphone"));
		t.setDate1(request.getParameter("mdate"));
		t.setTime(request.getParameter("mtime"));
		t.setMsg(request.getParameter("mmessage"));
		
		DAO d = new DAO();
		d.addTable(t);
		
		doGet(request, response);
	}

}
