package com.dto;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;


@WebServlet("/UpdateUserDataServlet")
public class UpdateUserDataServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String option = request.getParameter("value");
		String value ="";
	
		
		switch(option) {
		case "name":
			value = request.getParameter("userName");
			break;
		case "address":
			value = request.getParameter("userAddress");
			break;
		case "email":
			value = request.getParameter("userEmail");
			break;
		case "mobileNumber":
			value = request.getParameter("userMobileNumber");
			break;
		default:
			value = "a";
			break;
		}
		
		
		DAO d =  new DAO();
		if(d.updateUserData(request.getParameter("email"),value,option) > 0) {
			System.out.println("Updated");
			RequestDispatcher rd=request.getRequestDispatcher("profile.jsp");
			rd.forward(request,response); 
		}
		
		doGet(request, response);
	}

}
