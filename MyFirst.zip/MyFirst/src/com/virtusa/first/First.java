package com.virtusa.first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class First {

	public static void main(String[] args)
	{
		try 
		{
		Class.forName("com.mysql.jdbc.driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","root");
		Statement stmt = con.createStatement();
		
		//display all
		String sql = "select * from emp1";
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next())
		{
			System.out.println(rs.getInt(1));
		}
		/*
		//insert into
//		Statement stmt2 = con.createStatement();
		String sql2 = "insert into emp1 values('1008','Gomzuu','Chennai','30000');";
		stmt.executeUpdate(sql2);
		System.out.println("---------");
		String sql3 = "select * from emp1";
		ResultSet rs2 = stmt.executeQuery(sql3);
		while(rs2.next())
		{
			System.out.println(rs2.getInt(1));
		}
		*/
		// update 
		String sql4= "update emp1 set name='divya' where code=1004;";
		stmt.executeUpdate(sql4);
		System.out.println("---------");
		String sql5 = "select * from emp1";
		ResultSet rs3 = stmt.executeQuery(sql5);
		while(rs3.next())
		{
			System.out.println(rs3.getString(2));
		}
		
		//delete
		String sql6= "delete from emp1 where code=1004;";
		stmt.executeUpdate(sql6);
		System.out.println("---------");
		String sql7 = "select * from emp1";
		ResultSet rs4 = stmt.executeQuery(sql7);
		while(rs4.next())
		{
			System.out.println(rs4.getInt(1));
		}
		
		
	}
	catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

}
