package com.virtusa.profile.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="orderdetails")
public class Order {
	
	
	@Id
	@NotEmpty(message="Email can't be Empty")
	private String email;
	@NotEmpty(message="Item Name can't be Empty")
	private String itemName;
	@NotEmpty(message="Quantity can't be Empty")
	private String quantity;
	@NotEmpty(message="Amount can't be Empty")
	private String amount;
	@NotEmpty(message="Address can't be Empty")
	private String address;
	@NotEmpty(message="OrderNo can't be Empty")
	private String orderNo;
	
	
	
	public Order() {
		super();
	}



	public Order(String email, String itemName, String quantity, String amount, String address, String orderNo) {
		super();
		this.email = email;
		this.itemName = itemName;
		this.quantity = quantity;
		this.amount = amount;
		this.address = address;
		this.orderNo = orderNo;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getItemName() {
		return itemName;
	}



	public void setItemName(String itemName) {
		this.itemName = itemName;
	}



	public String getQuantity() {
		return quantity;
	}



	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}



	public String getAmount() {
		return amount;
	}



	public void setAmount(String amount) {
		this.amount = amount;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getOrderNo() {
		return orderNo;
	}



	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	
	

}
