package com.virtusa.profile.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.profile.model.Order;
import com.virtusa.profile.dao.ProfileDao;
import com.virtusa.profile.model.Users;


@Service
public class ProfileService {
	
	@Autowired
	private ProfileDao profileDao;
	
	public ProfileService() {
		System.out.println("ProfileService");
	}
	
		
	public Users viewData(String email) {
		System.out.println("viewService");
		Users u1 = profileDao.viewData(email);
		return u1;
	}


	public List<Order> orderData(String email) {
		List<Order> o = profileDao.orderData(email);
		return o;
	}


	public void updateUserData(String email, String value, String option) {
		profileDao.updateData(email,value,option);
		
	}
}
