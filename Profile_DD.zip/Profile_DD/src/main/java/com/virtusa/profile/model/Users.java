package com.virtusa.profile.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name ="userTable")
public class Users {
	
	@Id
	@NotEmpty(message="User Name can't be Empty")
	private String userName;
	@NotEmpty(message="Email can't be Empty")
	private String email;
	@NotEmpty(message="Password can't be Empty")
	@Length(min=8,max=15,message="minimum 8 and Max 15")
	private String password;
	@NotEmpty(message="Mobile Number can't be Empty")
	@Length(min=10,max=10,message="must contain 10 numbers")
	private long mobileNumber;
	@NotEmpty(message="Address can't be Empty")
	private String address;
	
	public Users() {
		
	}

	public Users(String userName,String email, String password, long mobileNumber, String address) {
		super();
		this.userName = userName;
		this.email = email;
		this.password = password;
		this.mobileNumber = mobileNumber;
		this.address = address;
	}

	public Users(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
	
	

}
