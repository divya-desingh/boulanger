package com.virtusa.profile.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.profile.model.*;

@Repository
public class ProfileDao {

	@Autowired
    private SessionFactory sessionFactory;
	
	@Transactional
	public Users viewData(String email) {
		
		System.out.println("ProfileDAO");
		
		List<Users> result = sessionFactory.getCurrentSession().createQuery("from Users where email=:email").setParameter("email",email).list();
		 
	    Users u1 = null;
	    for(Users user : result) {
	    	u1 = new Users(user.getUserName(),user.getEmail(),user.getPassword(),user.getMobileNumber(),user.getAddress());
	        System.out.println(user.getEmail());
	        System.out.println(user.getPassword());
	    } 
		
		return u1;
		
	}
	
	@Transactional
	public List<Order> orderData(String email) {
		
		List<Order> result = sessionFactory.getCurrentSession().createQuery("from Order where email=:email").setParameter("email",email).list();
	
		return result;
		
	}

	public void updateData(String email, String value, String option) {
		
		Query q;
		switch(option) {
	    case "name":
	    	q=sessionFactory.getCurrentSession().createQuery("update Users set userName=:a where email=:e"); 
	    	break;
	    case "email":
	    	q=sessionFactory.getCurrentSession().createQuery("update Users set email=:a where email=:e"); 
	    	break;
	    case "address":
	    	q=sessionFactory.getCurrentSession().createQuery("update Users set address=:a where email=:e");
	    	break;
	    case "mobileNumber":
	    	q=sessionFactory.getCurrentSession().createQuery("update Users set mobileNumber=:a where email=:e");
	    	break;
	    default:
	    	 q=sessionFactory.getCurrentSession().createQuery("update Users set simply=:a where email=:e"); 
	    	 break;
	    }
	    
	    q.setParameter("a",value);
	    q.setParameter("e",email);  
	    
	    
	    int status=q.executeUpdate();  
	    System.out.println(status);  
	   		
	}

	
}
