package model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orderdetails")
public class Order {
	
	
	@Id
	private String email;
	private String itemName;
	private String quantity;
	private String amount;
	private String address;
	private String orderNo;
	
	
	
	public Order() {
		super();
	}



	public Order(String email, String itemName, String quantity, String amount, String address, String orderNo) {
		super();
		this.email = email;
		this.itemName = itemName;
		this.quantity = quantity;
		this.amount = amount;
		this.address = address;
		this.orderNo = orderNo;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getItemName() {
		return itemName;
	}



	public void setItemName(String itemName) {
		this.itemName = itemName;
	}



	public String getQuantity() {
		return quantity;
	}



	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}



	public String getAmount() {
		return amount;
	}



	public void setAmount(String amount) {
		this.amount = amount;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getOrderNo() {
		return orderNo;
	}



	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	
	

}
