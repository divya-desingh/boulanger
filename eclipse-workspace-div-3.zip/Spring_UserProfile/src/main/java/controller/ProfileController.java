package controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import dao.Dao;
import model.Users;


@Controller
public class ProfileController {

	String email="divya@gmail.com";
	
	
	@RequestMapping("/profile")
	public String profile(Model model)
	{
			System.out.println("profile");
			Dao d = new Dao();
		    Users u1 = d.loginData(email);
			
			model.addAttribute("username",u1.getUserName());
			model.addAttribute("email",u1.getEmail());
			model.addAttribute("address",u1.getAddress());
			model.addAttribute("mobilenumber",u1.getMobileNumber());
						
			model.addAttribute("ordernumber","85798");
			model.addAttribute("quantity","3");
			model.addAttribute("cost","550");
			return "profile";
		
	}
	
	@RequestMapping("/update")
	public String update(Model model,HttpServletRequest request)
	{
		Dao d = new Dao();
		System.out.println("update");
		String option=request.getParameter("value");
		String value = null;
		switch(option) {
			case "name":
				value = request.getParameter("userName");
				break;
			case "address":
				value = request.getParameter("userAddress");
				break;
			case "email":
				value = request.getParameter("userEmail");
				break;
			case "mobileNumber":
				value = request.getParameter("userMobileNumber");
				break;
			default:
					break;
		}
		
		d.updateUserData(email, value, option);
		profile(model);
		return "profile";
	}
	
	
	@RequestMapping("/myorders")
	public String orders(Model model,@ModelAttribute Users u)
	{
		
		System.out.println("orders");
		
		model.addAttribute("ordernumber","85798");
		model.addAttribute("quantity","3");
		model.addAttribute("cost","550");
		return "profile";
	}
	
	@RequestMapping("/logout")
	public String logout()
	{
		return "index";
		
	}
	
	@RequestMapping("/home")
	public String home()
	{
		return "index";
		
	}
	
}
