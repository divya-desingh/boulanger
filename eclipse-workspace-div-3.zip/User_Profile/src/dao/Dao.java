package dao;


import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import HibernateConnection.Hibernate_Connection;

import main.*;




public class Dao {
	
	Hibernate_Connection h = new Hibernate_Connection();
	Session session = h.getConnection();

	
	public Users loginData(String email) {
		
		
		System.out.println("Came");
		Transaction tx=session.beginTransaction();
		
			
		
		List<Users> result = session.createQuery("from Users where email=:email").setParameter("email",email).list();
		 
	    Users u1 = null;
	    for(Users user : result) {
	    	u1 = new Users(user.getUserName(),user.getEmail(),user.getPassword(),user.getMobileNumber(),user.getAddress());
	        System.out.println(user.getEmail());
	        System.out.println(user.getPassword());
	    }  
        
	    tx.commit();
        session.close();
        return u1;
	    
	}
	
	
	
	
	public int updateUserData(String email,String value,String option) {
		
	    Transaction tx=session.beginTransaction();  
	    Query q;
	    
	    switch(option) {
	    case "name":
	    	q=session.createQuery("update Users set userName=:a where email=:e"); 
	    	break;
	    case "email":
	    	q=session.createQuery("update Users set email=:a where email=:e"); 
	    	break;
	    case "address":
	    	q=session.createQuery("update Users set address=:a where email=:e");
	    	break;
	    case "mobileNumber":
	    	
	    	q=session.createQuery("update Users set mobileNumber=:a where email=:e");
	    	break;
	    default:
	    	 q=session.createQuery("update Users set simply=:a where email=:e"); 
	    	 break;
	    }
	    
	    long l = 0;
	    if(option.equals("mobileNumber")) {
	    	l = Long.parseLong(value);
	    	q.setParameter("a",l);
	    }
	    else {
	    q.setParameter("a",value);
	    }
	    q.setParameter("e",email);  
	    
	    
	    int status=q.executeUpdate();  
	    System.out.println(status);  
	    tx.commit();
	     
	    session.close();   
		return status;
		
	}
	

	
	public List<Order> orderData(String email) {
		
		Transaction tx=session.beginTransaction();
		
		List<Order> result = session.createQuery("from Order where email=:email").setParameter("email",email).list();
		 
	    tx.commit();
        session.close();
        return result;
		
	}
	

	
}
