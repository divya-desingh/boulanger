package Profile;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UserProfileServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		System.out.println("success");
		request.setAttribute("name", "divya");
		request.setAttribute("email", "divya@gmail.com");
		request.setAttribute("address", "chennai");
		request.setAttribute("number", "987654321");
	    RequestDispatcher view= getServletContext().getRequestDispatcher("profile.jsp");
	    view.include(request,response);
		
	    doGet(request,response);
	}

}
