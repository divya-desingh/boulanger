package Profile;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Profile1 {
		
	public String u_name = "Divya";
	public String email = "divya@gmail.com";
	//public String address = "Chennai";
	public int mobilenumber = 987654325;
	
	public List u_address()
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		
		ProfilePojo u = new ProfilePojo();
		u.setU_name("vachu");
		u.setU_address("Chennai");
		u.setU_email("vachu@gmail.com");
		u.setU_number(94873876871L);
		session.save(u);
		
		String hql = "select u.u_address from userprofile u where u.u_name = :u_name";
		Query query = session.createQuery(hql);
		query.setParameter("u_name","vachu");
		List u_address = query.list();
		
		t.commit();
		factory.close();
		session.close();
		return u_address;
		
	}
}
