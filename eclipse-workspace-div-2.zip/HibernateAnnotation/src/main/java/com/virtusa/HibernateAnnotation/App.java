package com.virtusa.HibernateAnnotation;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class App {
	
	public static void main(String[] args)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		
		
		
		Employee e1 = new Employee();
		e1.setId(15);
		e1.setName("sush");

		Vehicle v = new Vehicle();
		v.setV_Id(118);
		v.setV_Name("activa");
		
		session.save(v);
		e1.setVehicle(v);
		session.save(e1);
		

		
		/*
		String hql = "select E.name FROM Employee E WHERE E.id = :employee_id";
		Query query = session.createQuery(hql);
		query.setParameter("employee_id",2);
		List results = query.list();
		for (Object o : results)
		{
			System.out.println(o);
		}
		*/
		t.commit();
		factory.close();
		session.close();
	}
	
}
