package com.virtusa.HibernateAnnotation;

import javax.persistence.*;

@Entity
@Table(name = "Vehicle")

public class Vehicle {
	@Id
	public int v_id;
	public String v_name; 
	
	
	public int getV_Id()
	{
		return v_id;
	}
	public void setV_Id(int id)
	{
		this.v_id = id;
	}
	
	public String getV_Name()
	{
		return v_name;
	}
	public void setV_Name(String name)
	{
		this.v_name = name;
	}
}


