package com.virtusa.register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegisterDb {
	public static void update(String name,String pass,String address,String mobileno){
		//boolean status=false;
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","root");
			
			
			PreparedStatement ps=con.prepareStatement("insert into userreg values (? , ? , ? , ?)");
			ps.setString(1,name);
			ps.setString(2,pass);
			ps.setString(3,address);
			ps.setString(4,mobileno);
			
			int rs=ps.executeUpdate();
			
			String sql = new String("Select * from userreg");
			ResultSet rs1 = ps.executeQuery(sql);
			while ( rs1.next())
			{
				System.out.println(rs1.getString(1));
			}
			
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		//return status;
		}
}
