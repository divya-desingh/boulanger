package com.virtusa.HibernateMany;


import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();
        Session session = factory.openSession();
        Transaction t = session.beginTransaction();
        
                
        Books b1 = new Books();
        b1.setB_id(1001);
        b1.setB_name("book1");
        
        
        Books b2 = new Books();
        b2.setB_id(1002);
        b2.setB_name("book2");
        
//        Books b2 = new Books (111, "Beauty and the Beast");
		Set<Books> b = new HashSet<Books>();
		b.add(b1);
		b.add(b2);
		
		Student st = new Student();
        st.setSt_id(22);
        st.setSt_name("Mini");
		st.setBooks(b);
		
        session.save(b1);
        session.save(b2);
        session.save(st);

        t.commit();
        session.close();
        factory.close();
        
    }
}
