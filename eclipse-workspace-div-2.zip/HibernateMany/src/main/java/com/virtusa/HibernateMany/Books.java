package com.virtusa.HibernateMany;

import javax.persistence.*;

@Entity
@Table(name="books")
public class Books {

	@Id
	private int b_id;
	private String b_name;
	
	@ManyToOne
	private Student student;

	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public int getB_id() {
		return b_id;
	}
	public void setB_id(int b_id) {
		this.b_id = b_id;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
}
